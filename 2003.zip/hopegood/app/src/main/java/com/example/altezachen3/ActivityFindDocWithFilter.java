package com.example.altezachen3;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

public class ActivityFindDocWithFilter extends AppCompatActivity implements View.OnClickListener {

    TextView itName, itPrice, itQuantity, itLength, itWidth, itHeight, itCatagory, docName;
    private FirebaseAuth mAuth;
    FirebaseUser currentUser;
    FirebaseFirestore db;
    Item item;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_find_doc_with_filter);

        itName = findViewById(R.id.textVName);
        itPrice = findViewById(R.id.textVPrice);
        itQuantity = findViewById(R.id.textVQuantity);
        itLength = findViewById(R.id.textVLength);
        itWidth = findViewById(R.id.textVWidth);
        itHeight = findViewById(R.id.textVHeight);
        itCatagory = findViewById(R.id.textVCategory);
        docName = findViewById(R.id.textVDocName);

    }

    @Override
    public void onStart() {
        super.onStart();

        mAuth = FirebaseAuth.getInstance();
        // Check if user is signed in (non-null) and update UI accordingly.
        currentUser = mAuth.getCurrentUser();

        db = FirebaseFirestore.getInstance();

        db.collection("collection").whereEqualTo("itemPrice", 100)
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                Log.d("DOCFOUND", document.getId() + " => " + document.getData());
                                item = document.toObject(Item.class);
                                Toast.makeText(ActivityFindDocWithFilter.this, item.toString(), Toast.LENGTH_LONG).show();
                            }
                        } else {
                            Log.d("DOCFOUND", "Error getting documents: ", task.getException());
                        }
                    }
                });
    }

    @Override
    public void onClick(View v) {

    }
}