package com.example.altezachen3;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.bumptech.glide.Glide;
import com.bumptech.glide.Registry;
import com.bumptech.glide.annotation.GlideModule;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.module.AppGlideModule;
import com.firebase.ui.storage.images.FirebaseImageLoader;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.io.InputStream;
import java.util.ArrayList;

public class ItemsLVAdapter extends ArrayAdapter<Item> implements AdapterView.OnItemSelectedListener {
    EditText preItNameD, preItPriceD, preItQuantityD, preItLengthD, preItWidthD, preItHeightD;
    FirebaseFirestore db;
    String itName, itPrice, itQuantity, itLength, itWidth, itHeight, catagoryS;
    String[] array_spinner = new String[4];
    Spinner spCatagory;
    int pos = 0;
    Intent toSeeAllItem;
    Item item;
    TextView tvItemName, tvPrice;
    ImageView photo;
    StorageReference storageReference, imgRef;

    public ItemsLVAdapter(@NonNull Context context, @NonNull ArrayList<Item> items) {
        super(context, 0, items);
        db = FirebaseFirestore.getInstance();
    }


    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View listItemView = convertView;
        toSeeAllItem = new Intent(this.getContext(), ItemEntireData.class);
        if (listItemView == null) {
            listItemView = LayoutInflater.from(getContext()).inflate(R.layout.item_adapter_layout_each_line, parent, false);
        }

        item = getItem(position);
        pos = position;
        storageReference = FirebaseStorage.getInstance().getReference();
        imgRef = storageReference.child(item.getItImagePath());

        TextView n1 = listItemView.findViewById(R.id.has_user);
        db.collection("users").document(item.creatorMail).get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if(task.isSuccessful())
                    n1.setText(task.getResult().get("accountName",String.class));
                else
                    n1.setText("hasen't");
            }
        });
        tvItemName = listItemView.findViewById(R.id.TVNameOfItem);
        tvPrice = listItemView.findViewById(R.id.TVPriceOfItem);
        photo = listItemView.findViewById(R.id.image);
        if (item.getItImagePath() != null) {
            Log.d("CHN", imgRef.getPath());
            Glide.with(getContext())
                    .load(imgRef)
                    .diskCacheStrategy(DiskCacheStrategy.NONE)
                    .into(photo);
        }

        tvItemName.setText(item.getItemName());
        tvPrice.setText(String.valueOf(item.getItemPrice()) + "$");


        array_spinner[0] = "Chair";
        array_spinner[1] = "Sofa";
        array_spinner[2] = "Table";
        array_spinner[3] = "Other";
        if (item.getItemPrice() >= 1000)
            tvPrice.setTextColor(Color.RED);
        else if (item.getItemPrice() < 1000)
            tvPrice.setTextColor(Color.GREEN);

        listItemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                item = getItem(position);
                AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
                LayoutInflater inflater = getContext().getSystemService(LayoutInflater.class);
                View dialogView = inflater.inflate(R.layout.dialog_show_item_propretys, null);
                builder.setView(dialogView);
                spCatagory = dialogView.findViewById(R.id.spinnerCatgory);
                ArrayAdapter<String> adapter = new ArrayAdapter<String>(getContext(), android.R.layout.simple_spinner_item, array_spinner);
                spCatagory.setAdapter(adapter);
                spCatagory.setOnItemSelectedListener(ItemsLVAdapter.this);
                String itCat = item.getCategory();
                if (itCat.equals("Chair")) {
                    spCatagory.setSelection(adapter.getPosition("Chair"));
                } else if (itCat.equals("Sofa")) {
                    spCatagory.setSelection(adapter.getPosition("Sofa"));
                } else if (itCat.equals("Table")) {
                    spCatagory.setSelection(adapter.getPosition("Table"));
                } else if (itCat.equals("Other")) {
                    Log.d("SPIN", itCat);
                    spCatagory.setSelection(adapter.getPosition("Other"));
                }
                preItHeightD = dialogView.findViewById(R.id.editItHeightD);
                preItWidthD = dialogView.findViewById(R.id.editItWidthD);
                preItLengthD = dialogView.findViewById(R.id.editItLengthD);
                preItQuantityD = dialogView.findViewById(R.id.editItQuantityD);
                preItPriceD = dialogView.findViewById(R.id.editItPriceD);
                preItNameD = dialogView.findViewById(R.id.editItNameD);

                preItHeightD.setText(String.valueOf(item.getItemSize().getItemY()));
                preItWidthD.setText(String.valueOf(item.getItemSize().getItemZ()));
                preItLengthD.setText(String.valueOf(item.getItemSize().getItemX()));
                preItQuantityD.setText(String.valueOf(item.getItemQuantity()));
                preItPriceD.setText(String.valueOf(item.getItemPrice()));
                preItNameD.setText(item.getItemName());
                String nameBefore = preItNameD.getText().toString();

                builder.setNegativeButton("Delete", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        //delete it
                        Log.d("del", "onClick: " +item.getIdItem());
                        db.collection("collection3").document(item.getIdItem()).delete().addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void unused) {
                                Toast.makeText(getContext(), "WALLAK DELETED", Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                });
                builder.setNeutralButton("Change", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {

                        Item updatedItem = createItem(item.getIdItem(), preItHeightD, preItWidthD, preItLengthD, preItQuantityD, preItPriceD, preItNameD);

                        db.collection("collection3").document(item.getIdItem()).set(updatedItem).addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void aVoid) {
                                Toast.makeText(getContext(), "Wallak changed", Toast.LENGTH_LONG).show();
                                ListViewSeeingStuff.changeNotf(getContext(), nameBefore, preItNameD.getText().toString());
                            }
                        }).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Toast.makeText(getContext(), "Couldn't Change", Toast.LENGTH_SHORT).show();
                            }
                        });


                    }

                    private Item createItem(String id, EditText preItHeightD, EditText preItWidthD, EditText preItLengthD, EditText preItQuantityD, EditText preItPriceD, EditText preItNameD) {
                        itPrice = preItPriceD.getText().toString();
                        itName = preItNameD.getText().toString();
                        itQuantity = preItQuantityD.getText().toString();
                        itLength = preItLengthD.getText().toString();
                        itWidth = preItWidthD.getText().toString();
                        itHeight = preItHeightD.getText().toString();
                        ItemSize size1 = new ItemSize(Double.parseDouble(itWidth), Double.parseDouble(itLength), Double.parseDouble(itHeight));
                        Item item1 = new Item(itName, Double.parseDouble(itPrice), Integer.parseInt(itQuantity), size1, catagoryS, item.getItImagePath(), item.getCreatorMail());
                        item1.setIdItem(id);
                        return item1;
                    }
                });
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });
        return listItemView;
    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        catagoryS = adapterView.getItemAtPosition(i).toString();
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {
        catagoryS = "Chair";
    }


}
