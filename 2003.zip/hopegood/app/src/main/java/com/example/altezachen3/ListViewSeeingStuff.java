package com.example.altezachen3;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.SearchView;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.SystemClock;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.firestore.WriteBatch;

import java.util.ArrayList;
import java.util.List;

public class ListViewSeeingStuff extends BasicActivity implements SearchView.OnQueryTextListener, View.OnClickListener {

    FirebaseFirestore db;
    ListView lvAllItems;
    ArrayList<Item> alAllItems;
    ProgressBar progressBarListView;
    public static Intent intentService;
    public static int myFlag = 0;
    SearchView searchView;
    ItemsLVAdapter adapter;
    Button filterByprice, filterByQuantity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_view_seeing_stuff);
        db = FirebaseFirestore.getInstance();
        lvAllItems = findViewById(R.id.ListViewShowingItems);
        filterByprice = findViewById(R.id.btFilterByPrice);
        filterByQuantity = findViewById(R.id.btFilterByQuantity);
        alAllItems = new ArrayList<>();
        progressBarListView = findViewById(R.id.progressListView);
        searchView = findViewById(R.id.SView);
        loadItemsToListView();
        intentService = new Intent(this, Service_Add_Notif.class);
        searchView.setOnQueryTextListener(this);
        filterByprice.setOnClickListener(this);
        filterByQuantity.setOnClickListener(this);
    }

    private void loadItemsToListView() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                db.collection("collection3").get()
                        .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                            @Override
                            public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                                if (!queryDocumentSnapshots.isEmpty()) {
                                    List<DocumentSnapshot> list = queryDocumentSnapshots.getDocuments();
                                    Log.d(getString(R.string.TAG), "List size: " + list.size());
                                    for (DocumentSnapshot d : list) {
                                        DocumentReference sfRef = d.getReference();
                                        if (d.get("idItem", String.class) == null) {
                                            sfRef.update("idItem", d.getId());
                                        }
                                        Item item = d.toObject(Item.class);
                                        alAllItems.add(item);
                                    }
                                    adapter = new ItemsLVAdapter(ListViewSeeingStuff.this, alAllItems);
                                    lvAllItems.setAdapter(adapter);
                                    progressBarListView.setVisibility(View.GONE);
                                } else {
                                    Log.d(getString(R.string.TAG), "No data found in query");
                                    Toast.makeText(ListViewSeeingStuff.this, "No data found in Database", Toast.LENGTH_SHORT).show();
                                }

                            }
                        }).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                // when we get any error from Firebase.
                                Toast.makeText(ListViewSeeingStuff.this, "Fail to load data..", Toast.LENGTH_SHORT).show();
                            }
                        });

            }
        }).start();
    }

    public static void changeNotf(Context context, String nameBeforeChange, String nameAfterChange) {
        intentService.putExtra("NameItBefore", nameBeforeChange);
        intentService.putExtra("NameItAfter", nameAfterChange);
        SystemClock.sleep(5000);
        context.startService(intentService);
    }


    @Override
    public boolean onQueryTextSubmit(String query) {
        ListViewSeeingStuff.this.adapter.getFilter().filter(query);
        return false;
    }

    @Override
    public boolean onQueryTextChange(String newText) {
        ListViewSeeingStuff.this.adapter.getFilter().filter(newText);
        return false;
    }

    @Override
    public void onClick(View v) {
        ArrayList<Item> allFiltered = new ArrayList<>();
        if (v == filterByprice) {
            filterByprice(allFiltered, "itemPrice");
            Toast.makeText(this, "Filtered by price", Toast.LENGTH_SHORT).show();
        } else if (v == filterByQuantity) {
            filterByprice(allFiltered, "itemQuantity");
            Toast.makeText(this, "Filtered by Quantity", Toast.LENGTH_SHORT).show();
        }

    }

    private void filterByprice(ArrayList<Item> allFiltered, String sort) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                db.collection("collection3").orderBy(sort, Query.Direction.ASCENDING).get()
                        .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                            @Override
                            public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                                if (!queryDocumentSnapshots.isEmpty()) {
                                    List<DocumentSnapshot> list = queryDocumentSnapshots.getDocuments();
                                    Log.d(getString(R.string.TAG), "List size: " + list.size());
                                    for (DocumentSnapshot d : list) {
                                        Item item = d.toObject(Item.class);
                                        item.setIdItem(d.getId());
                                        allFiltered.add(item);
                                    }
                                    adapter = new ItemsLVAdapter(ListViewSeeingStuff.this, allFiltered);
                                    lvAllItems.setAdapter(adapter);
                                } else {
                                    Log.d(getString(R.string.TAG), "No data found in query");
                                    Toast.makeText(ListViewSeeingStuff.this, "No data found in Database", Toast.LENGTH_SHORT).show();
                                }

                            }
                        }).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Toast.makeText(ListViewSeeingStuff.this, "Fail to load data..", Toast.LENGTH_SHORT).show();
                            }
                        });

            }
        }).start();
    }
}
