package com.example.altezachen3;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.content.BroadcastReceiver;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import org.checkerframework.checker.index.qual.GTENegativeOne;

import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener {
    Button signUp, logIn;
    private FirebaseAuth mAuth;
    String email;
    String password;
    EditText emailPre;
    EditText passwordPre;
    BroadcastReceiver broadcastReceiver;
    FirebaseFirestore db;
    Intent logToCraeteAccount,logToAccount;
    Integer REQUEST_CODE_PERMISSIONS = 100;
    ProgressBar pr;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.actvity_loadin_screen);
        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();
        loadData();
    }
    private void loadData() {
        Executor executor = Executors.newCachedThreadPool();
        executor.execute(() -> {
            broadcastReceiver = new WiFiConnectioOn();
            registerNetworkBroadcastReciver();
            // Check if user is signed in (non-null) and update UI accordingly.
            FirebaseUser currentUser = mAuth.getCurrentUser();
            if (currentUser != null){
                reload();}//לעשות שברילוד אם יש משתמש שיעביר ישר למסך השני ובכך יהיה פינגפונג

            runOnUiThread(() -> {
                // Switch the content view back to the original layout
                setContentView(R.layout.activity_main);
//                pr = findViewById(R.id.login_proggres_bar);
                signUp = findViewById(R.id.btSignUp);
                logIn = findViewById(R.id.btRegister);
                emailPre = findViewById(R.id.editMail);
                passwordPre = findViewById(R.id.editPassword);
                if(currentUser != null)
                {emailPre.setVisibility(View.GONE);
                    passwordPre.setVisibility(View.GONE);
                    signUp.setVisibility(View.GONE);
                    logIn.setVisibility(View.GONE);}
                logToAccount = new Intent(LoginActivity.this, GridView.class);
                logToCraeteAccount = new Intent(LoginActivity.this, UserCreate.class);
                signUp.setOnClickListener(this);
                logIn.setOnClickListener(this);

            });
        });
    }


    protected void registerNetworkBroadcastReciver() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            registerReceiver(broadcastReceiver, new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION));
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            registerReceiver(broadcastReceiver, new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION));
        }
    }

    protected void unregisterNetwork() {
        try {
            unregisterReceiver(broadcastReceiver);
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterNetwork();
    }

    @Override
    public void onStart() {
        super.onStart();
//        // Check if user is signed in (non-null) and update UI accordingly.
//        FirebaseUser currentUser = mAuth.getCurrentUser();
//        if (currentUser != null){
//            emailPre.setVisibility(View.GONE);
//            passwordPre.setVisibility(View.GONE);
//            signUp.setVisibility(View.GONE);
//            logIn.setVisibility(View.GONE);
//            reload();}//לעשות שברילוד אם יש משתמש שיעביר ישר למסך השני ובכך יהיה פינגפונג
//        else
//            pr.setVisibility(View.GONE);
    }

    public void onClick(View v) {
        PackageManager pm = getPackageManager();
        if (pm.checkPermission(android.Manifest.permission.ACCESS_NETWORK_STATE, getPackageName()) != PackageManager.PERMISSION_GRANTED
                || pm.checkPermission(android.Manifest.permission.INTERNET, getPackageName()) != PackageManager.PERMISSION_GRANTED
                || pm.checkPermission(android.Manifest.permission.CAMERA, getPackageName()) != PackageManager.PERMISSION_GRANTED
                || pm.checkPermission(android.Manifest.permission.VIBRATE, getPackageName()) != PackageManager.PERMISSION_GRANTED
                || pm.checkPermission(android.Manifest.permission.POST_NOTIFICATIONS, getPackageName()) != PackageManager.PERMISSION_GRANTED
                || pm.checkPermission(android.Manifest.permission.READ_EXTERNAL_STORAGE, getPackageName()) != PackageManager.PERMISSION_GRANTED) {
            // Some permissions are not granted
            // Request the missing permissions
            ActivityCompat.requestPermissions(this,
                    new String[] { android.Manifest.permission.ACCESS_NETWORK_STATE,
                            android.Manifest.permission.INTERNET,
                            android.Manifest.permission.CAMERA,
                            android.Manifest.permission.VIBRATE,
                            android.Manifest.permission.POST_NOTIFICATIONS,
                            android.Manifest.permission.READ_EXTERNAL_STORAGE },
                    REQUEST_CODE_PERMISSIONS);
        } else {
            // All permissions are granted
            // Do your work here

            password = passwordPre.getText().toString();
            email = emailPre.getText().toString();
            if (v == signUp) {
                mAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            Log.d("Auth", "createUserWithEmail:success");
                            FirebaseUser user = mAuth.getCurrentUser();
                            Intent toUserCreate = new Intent(LoginActivity.this, UserCreate.class);
                            startActivity(toUserCreate);
                        } else {
                            // If sign in fails, display a message to the user.
                            Log.w("Auth", "createUserWithEmail:failure", task.getException());
                            Toast.makeText(LoginActivity.this, "Authentication failed.", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
                Toast.makeText(this, "signing up", Toast.LENGTH_SHORT).show();
            } else if (v == logIn) {
                Toast.makeText(this, "log in", Toast.LENGTH_SHORT).show();
                mAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            Log.d("logIn", "signInWithEmail:success");
                            FirebaseUser authContext = mAuth.getCurrentUser();
                            DocumentReference docRef = db.collection("users").document(mAuth.getCurrentUser().getEmail());
                            docRef.get().addOnCompleteListener(task2 -> {
                                if (task2.isSuccessful()) {
                                    DocumentSnapshot document = task2.getResult();
                                    if (document.exists()) {
                                        startActivity(logToAccount);
                                    } else {
                                        startActivity(logToCraeteAccount);
                                    }
                                } else {
                                    Log.d("US", "error");
                                }
                            });
                        } else {
                            // If sign in fails, display a message to the user.
                            Log.w("logIn", "signInWithEmail:failure", task.getException());
                            Toast.makeText(LoginActivity.this, "Authentication failed.", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        }
    }

    private void reload() {
        Log.d("OpenItemPost", "Open Item Post");
        DocumentReference docRef = db.collection("users").document(mAuth.getCurrentUser().getEmail());
        docRef.get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                DocumentSnapshot document = task.getResult();
                if (document.exists()) {
                    startActivity(logToAccount);
                } else {
                    startActivity(logToCraeteAccount);
                }
            } else {
                Log.d("US", "error");
            }
        });

    }

}