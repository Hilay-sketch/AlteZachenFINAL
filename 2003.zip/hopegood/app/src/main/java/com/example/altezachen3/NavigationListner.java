package com.example.altezachen3;

import static androidx.core.content.ContextCompat.startActivity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.MenuItem;

import androidx.annotation.NonNull;

import com.google.android.material.navigation.NavigationBarView;

public class NavigationListner implements NavigationBarView.OnItemSelectedListener {

    private Activity activity;
    public NavigationListner(Activity activity) {
        this.activity = activity;
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem Mitem) {
        if (Mitem.getItemId() == R.id.bt_menu_profile) {
            activity.startActivity(new Intent(activity, ActivityProfile.class));
            return true;
        } else if (Mitem.getItemId() == R.id.bt_menu_createPost) {
            activity.startActivity(new Intent(activity, ItemPost.class));
            return true;
        } else if (Mitem.getItemId() == R.id.bt_menu_gridView) {
            activity.startActivity(new Intent(activity, GridView.class));
            return true;
        }
        return false;
    }
}
