package com.example.altezachen3;

public class Item {
    private String id;//id לזהוי אחרי זה
    private String itemName;//שם המוצר
    private double itemPrice;//מחיר המוצר
    private int itemQuantity;//כמה יש מהמוצר
    private ItemSize itemSize;//גדלי המוצר
    private String category;//קטוגריה של המוצר(ספות/כורסאות/שולחנות וכו')

    public Item() {
    }//פעולה ריקה

    public Item(String itemName, double itemPrice, int itemQuantity, ItemSize itemSize, String category) {
        this.itemName = itemName;
        this.id = null;
        this.itemPrice = itemPrice;
        this.itemQuantity = itemQuantity;
        this.itemSize = itemSize;
        this.category = category;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public double getItemPrice() {
        return itemPrice;
    }

    public void setItemPrice(double itemPrice) {
        this.itemPrice = itemPrice;
    }

    public int getItemQuantity() {
        return itemQuantity;
    }

    public void setItemQuantity(int itemQuantity) {
        this.itemQuantity = itemQuantity;
    }

    public ItemSize getItemSize() {
        return itemSize;
    }

    public void setItemSize(ItemSize itemSize) {
        this.itemSize = itemSize;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "Post{" +
                "itemName='" + itemName + '\'' +
                ", itemPrice=" + itemPrice +
                ", itemQuantity=" + itemQuantity +
                ", itemSize=" + itemSize.toString() +
                ", category='" + category + '\'' +
                '}';
    }
}
