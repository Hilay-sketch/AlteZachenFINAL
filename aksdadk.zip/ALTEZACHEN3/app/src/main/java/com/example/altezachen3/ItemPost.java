package com.example.altezachen3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ClipData;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firestore.v1.FirestoreGrpc;

import org.w3c.dom.Text;

public class ItemPost extends BasicActivity implements View.OnClickListener {
    Button  change, add, delete, toFindDoc, toSeeAllDoc;
    private FirebaseAuth mAuth;
    FirebaseUser currentUser;
    FirebaseFirestore db;
    TextView txUserName;
    EditText preItName, preItPrice, preItQuantity, preItLength, preItWidth, preItHeight, preCatagory, preDocName;
    String itName, itPrice, itQuantity, itLength, itWidth, itHeight, itCatagory, docName;
    Item item1;
    ItemSize size1;
    Intent intentToFindDoc, intentToSeeAllDoc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_post);
        mAuth = FirebaseAuth.getInstance();

        txUserName = findViewById(R.id.txUser);

        change = findViewById(R.id.btChangeCurrentValues);
        add = findViewById(R.id.btAddCurrentValues);
        delete = findViewById(R.id.btDelete);
        toFindDoc = findViewById(R.id.btFindDoc);
        toSeeAllDoc = findViewById(R.id.btGoToListView);

        preItName = findViewById(R.id.editItName);
        preItPrice = findViewById(R.id.editItPrice);
        preCatagory = findViewById(R.id.editItCatagory);
        preItHeight = findViewById(R.id.editItHeight);
        preItQuantity = findViewById(R.id.editItQuantity);
        preItWidth = findViewById(R.id.editItWidth);
        preItLength = findViewById(R.id.editItLength);
        preDocName = findViewById(R.id.editDOC);

        db = FirebaseFirestore.getInstance();

        change.setOnClickListener(this);
        add.setOnClickListener(this);
        delete.setOnClickListener(this);
        toFindDoc.setOnClickListener(this);
        toSeeAllDoc.setOnClickListener(this);
    }

    @Override
    public void onStart() {
        super.onStart();
        // Check if user is signed in (non-null) and update UI accordingly.
        currentUser = mAuth.getCurrentUser();
        if (currentUser != null)
            reload();
        txUserName.setText(currentUser.getEmail());
    }

    private void reload() {
    }

    @Override
    public void onClick(View v) {
       if (v == add) {
            docName = preDocName.getText().toString();
            db.collection("collection2").document(docName).set(createItem());
            Toast.makeText(this, "Added", Toast.LENGTH_SHORT).show();
        } else if (v == change) {
            docName = preDocName.getText().toString();
            db.collection("collection2").document(docName).set(createItem());
            Toast.makeText(this, "Changed", Toast.LENGTH_SHORT).show();
        } else if (v == delete) {
            docName = preDocName.getText().toString();
            db.collection("collection2").document(docName).delete();
            Toast.makeText(this, "Deleted", Toast.LENGTH_SHORT).show();
        }
        else if(v == toFindDoc)
        {
            intentToFindDoc = new Intent(this, Collections.class);
            startActivity(intentToFindDoc);
        }
        else if(v == toSeeAllDoc)
        {
            intentToSeeAllDoc = new Intent(this, ListViewSeeingStuff.class);
            startActivity(intentToSeeAllDoc);
        }
    }

    public Item createItem() {//יוצר עצם שאותו אני שומר
        itPrice = preItPrice.getText().toString();
        itName = preItName.getText().toString();
        itQuantity = preItQuantity.getText().toString();
        itLength = preItLength.getText().toString();
        itWidth = preItWidth.getText().toString();
        itHeight = preItHeight.getText().toString();
        itCatagory = preCatagory.getText().toString();
        size1 = new ItemSize(Integer.parseInt(itWidth), Integer.parseInt(itLength), Integer.parseInt(itHeight));
        item1 = new Item(itName, Integer.parseInt(itPrice), Integer.parseInt(itQuantity), size1, itCatagory);
        item1.setId(preDocName.getText().toString());
        return item1;
    }
}
