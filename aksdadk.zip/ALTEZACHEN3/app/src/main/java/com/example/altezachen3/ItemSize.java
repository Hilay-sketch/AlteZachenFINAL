package com.example.altezachen3;

public class ItemSize //מחלקת גדלים
{
    private double itemX;
    private double itemY;
    private double itemZ;

    public ItemSize() {
    }

    public ItemSize(double itemX, double itemY, double itemZ) {
        this.itemX = itemX;
        this.itemY = itemY;
        this.itemZ = itemZ;
    }

    public double getItemX() {
        return itemX;
    }

    public void setItemX(double itemX) {
        this.itemX = itemX;
    }

    public double getItemY() {
        return itemY;
    }

    public void setItemY(double itemY) {
        this.itemY = itemY;
    }

    public double getItemZ() {
        return itemZ;
    }

    public void setItemZ(double itemZ) {
        this.itemZ = itemZ;
    }
    //טענת יציאה: נפח המוצר
    public double Volume()
    {
        return itemX*itemY*itemZ;
    }
    @Override
    public String toString() {
        return "ItemSizeINMETERS{" +
                "itemX=" + itemX +
                ", itemY=" + itemY +
                ", itemZ=" + itemZ +
                '}';
    }
}

