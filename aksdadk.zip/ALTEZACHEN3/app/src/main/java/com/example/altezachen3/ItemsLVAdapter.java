package com.example.altezachen3;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.firebase.firestore.FirebaseFirestore;
import com.google.protobuf.Enum;

import java.util.ArrayList;

public class ItemsLVAdapter extends ArrayAdapter<Item> {
    EditText preItNameD, preItPriceD, preItQuantityD, preItLengthD, preItWidthD, preItHeightD, preCatagoryD;
    FirebaseFirestore db;
    String itName, itPrice, itQuantity, itLength, itWidth, itHeight, itCatagory;
    public ItemsLVAdapter(@NonNull Context context, @NonNull ArrayList<Item> items)
    {
        super(context, 0, items);
        db = FirebaseFirestore.getInstance();
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent)
    {
        View listItemView = convertView;

        if (listItemView==null)
        {
            listItemView = LayoutInflater.from(getContext()).inflate(R.layout.item_adapter_layout_each_line, parent, false);
        }

        Item item = getItem(position);

        TextView tvItemName =  listItemView.findViewById(R.id.TVNameOfItem);
        TextView tvPrice =  listItemView.findViewById(R.id.TVPriceOfItem);

        tvItemName.setText(item.getItemName());
        tvPrice.setText(String.valueOf(item.getItemPrice())+ "$");

        if (item.getItemPrice() >= 1000)
            tvPrice.setTextColor(Color.RED);
        else if (item.getItemPrice() < 1000)
            tvPrice.setTextColor(Color.GREEN);


        listItemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
                builder.setView(R.layout.dialog_show_item_propretys);

                builder.setPositiveButton("Delete", new DialogInterface.OnClickListener()
                {
                    public void onClick(DialogInterface dialog, int id) {
                        //delete it
                        db.collection("collection2").document(item.getId()).delete();
                        Toast.makeText(getContext(), "WALLAK DELETED", Toast.LENGTH_SHORT).show();
                    }
                });
                builder.setNegativeButton("Change", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id)
                    {
                        preCatagoryD = view.findViewById(R.id.editItCatagoryD);
                        preItHeightD = view.findViewById(R.id.editItHeightD);
                        preItWidthD = view.findViewById(R.id.editItWidthD);
                        preItLengthD = view.findViewById(R.id.editItLengthD);
                        preItQuantityD = view.findViewById(R.id.editItQuantityD);
                        preItPriceD = view.findViewById(R.id.editItPriceD);
                        preItNameD = view.findViewById(R.id.editItNameD);
                        db.collection("collection2").document(item.getId()).set(createItem(item.getId()));
                        Toast.makeText(getContext(), "Wallak Changed", Toast.LENGTH_SHORT).show();
                    }
                });

                AlertDialog dialog = builder.create();

                // EditText edit = (EditText) ((AlertDialog) dialog).findViewById(R.id.the_id_of_view);

                dialog.show();

            }
        });

        return listItemView;
    }

    public Item createItem(String id) {//יוצר עצם שאותו אני שומר
        itPrice = preItPriceD.getText().toString();
        itName = preItNameD.getText().toString();
        itQuantity = preItQuantityD.getText().toString();
        itLength = preItLengthD.getText().toString();
        itWidth = preItWidthD.getText().toString();
        itHeight = preItHeightD.getText().toString();
        itCatagory = preCatagoryD.getText().toString();
        ItemSize size1 = new ItemSize(Integer.parseInt(itWidth), Integer.parseInt(itLength), Integer.parseInt(itHeight));
        Item item1 = new Item(itName, Integer.parseInt(itPrice), Integer.parseInt(itQuantity), size1, itCatagory);
        item1.setId(id);
        return item1;
    }
}
