package com.example.altezachen3;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;

public class ListViewSeeingStuff extends BasicActivity {

    FirebaseFirestore db;
    ListView lvAllItems;
    ArrayList<Item> alAllItems;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_view_seeing_stuff);
        db = FirebaseFirestore.getInstance();
        lvAllItems = findViewById(R.id.ListViewShowingItems);
        alAllItems = new ArrayList<>();

        loadItemsToListView();
    }

    private void loadItemsToListView() {
        db.collection("collection2").get()
                .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                    @Override
                    public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                        // after getting the data we are calling on success method
                        // and inside this method we are checking if the received
                        // query snapshot is empty or not.
                        if (!queryDocumentSnapshots.isEmpty())
                        {
                            // if the snapshot is not empty we are hiding
                            // our progress bar and adding our data in a list.
                            List<DocumentSnapshot> list = queryDocumentSnapshots.getDocuments();
                            Log.d(getString(R.string.TAG), "List size: " + list.size());
                            for (DocumentSnapshot d : list) {
                                // after getting this list we are passing
                                // that list to our object class.
                                Item item = d.toObject(Item.class);
                                Log.d(getString(R.string.TAG), "WORKED HOPEFULLY");
                                // after getting data from Firebase we are
                                // storing that data in our array list
                                alAllItems.add(item);
                            }
                            // after that we are passing our array list to our adapter class.
                            ItemsLVAdapter adapter = new ItemsLVAdapter(ListViewSeeingStuff.this, alAllItems);

                            // after passing this array list to our adapter
                            // class we are setting our adapter to our list view.
                            lvAllItems.setAdapter(adapter);
                        }
                        else
                        {
                            Log.d(getString(R.string.TAG),"No data found in query");
                            // if the snapshot is empty we are displaying a toast message.
                            Toast.makeText(ListViewSeeingStuff.this, "No data found in Database", Toast.LENGTH_SHORT).show();
                        }
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        // we are displaying a toast message
                        // when we get any error from Firebase.
                        Toast.makeText(ListViewSeeingStuff.this, "Fail to load data..", Toast.LENGTH_SHORT).show();
                    }
                });
    }


}