package com.example.altezachen3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class MainAc2 extends AppCompatActivity implements View.OnClickListener {
    Button logOut;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_ac2);
        mAuth = FirebaseAuth.getInstance();
    }

    FirebaseUser currentUser;

    @Override
    public void onStart() {
        super.onStart();
        // Check if user is signed in (non-null) and update UI accordingly.
        currentUser = mAuth.getCurrentUser();
        if (currentUser != null)
            reload();
    }

    private void reload() {
    }

    @Override
    public void onClick(View v) {
        if (v == logOut) {
            mAuth.signOut();
            finish();
        }

    }
}