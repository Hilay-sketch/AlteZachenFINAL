package com.example.altezachen3;

import java.util.ArrayList;

public class PrivateManufacturer extends Profile
{
    private String location;//מיקום החברה
    private String mail;//מייל החברה
    private String manufacturerType;//איזה סוג הוא מפיץ/מייצר (לדוגמה יד שנייה, בדים, פרווה)
    private ArrayList<Item> postsList;//רשימה של כל המוצרים


    public PrivateManufacturer(String accountName, String accountPassword, String country, ArrayList<String> searchHistory, String phoneNumber, String location, String mail, String manufacturerType, ArrayList<Item> postsList) {
        super(accountName, accountPassword, country, searchHistory, phoneNumber);
        this.location = location;
        this.mail = mail;
        this.manufacturerType = manufacturerType;
        this.postsList = postsList;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    public String getManufacturerType() {
        return manufacturerType;
    }

    public void setManufacturerType(String manufacturerType) {
        this.manufacturerType = manufacturerType;
    }

    public ArrayList<Item> getPostsList() {
        return postsList;
    }

    public void setPostsList(ArrayList<Item> postsList) {
        this.postsList = postsList;
    }

    @Override
    public String toString() {
        return "com.example.altezachen3.PrivateManufacturer{" +
                "location='" + location + '\'' +
                ", mail='" + mail + '\'' +
                ", manufacturerType='" + manufacturerType + '\'' +
                ", postsList=" + postsList +
                '}';
    }
}
