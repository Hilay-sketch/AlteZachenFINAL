package com.example.altezachen3;

import java.util.ArrayList;

//אב המחלקות בתוכו התכונות הנמצאות אצל כל הפרופילים האפשריים
public class Profile
{
    private String accountName;//שם המשתמש
    protected String accountPassword;//סיסמה לחשבון
    private String country;//מיקום החשבון/העסק
    private ArrayList<String> searchHistory = new ArrayList<String>(); // מערך של החיפושים האחרונים של המשתמש
    private String phoneNumber;//מס' פלאפון של החשבון/העסק
    public Profile(){}
    public Profile(String accountName, String accountPassword, String country, ArrayList<String> searchHistory, String phoneNumber) {
        this.accountName = accountName;
        this.accountPassword = accountPassword;
        this.country = country;
        this.searchHistory = searchHistory;
        this.phoneNumber = phoneNumber;
    }

    public String getAccountName() {
        return accountName;
    }

    public void setAccountName(String accountName) {
        this.accountName = accountName;
    }

    public String getAccountPassword() {
        return accountPassword;
    }

    public void setAccountPassword(String accountPassword) {
        this.accountPassword = accountPassword;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public ArrayList<String> getSearchHistory() {
        return searchHistory;
    }

    public void setSearchHistory(ArrayList<String> searchHistory) {
        this.searchHistory = searchHistory;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    @Override
    public String toString() {
        return "com.example.altezachen3.Profile{" +
                "accountName='" + accountName + '\'' +
                ", accountPassword='" + accountPassword + '\'' +
                ", country='" + country + '\'' +
                ", searchHistory=" + searchHistory +
                ", phoneNumber='" + phoneNumber + '\'' +
                '}';
    }
}

