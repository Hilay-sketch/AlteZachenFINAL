package com.example.altezachen3;

public class Sale //מכירה של פריט
{
    private Profile sellingClient;//מוכר
    private Profile buyingClient;//קונה
    private Item itemSold;//חפץ שנמכר
    private boolean shipping;//האם נצטרך שילוח של המוצר אל בית הלקוח

    public Sale(Profile sellingClient, Profile buyingClient, Item itemSold, boolean shipping) {
        this.sellingClient = sellingClient;
        this.buyingClient = buyingClient;
        this.itemSold = itemSold;
        this.shipping = shipping;
    }

    public Sale() {
    }

    public Profile getSellingClient() {
        return sellingClient;
    }

    public void setSellingClient(Profile sellingClient) {
        this.sellingClient = sellingClient;
    }

    public Profile getBuyingClient() {
        return buyingClient;
    }

    public void setBuyingClient(Profile buyingClient) {
        this.buyingClient = buyingClient;
    }

    public Item getItemSold() {
        return itemSold;
    }

    public void setItemSold(Item itemSold) {
        this.itemSold = itemSold;
    }

    public boolean isShipping() {
        return shipping;
    }

    public void setShipping(boolean shipping) {
        this.shipping = shipping;
    }

    //מחזיר מחיר סופי של המכירה
    public double finalPrice() {
        if (shipping)
            return itemSold.getItemPrice() * 1.22;
        return itemSold.getItemPrice();
    }

    public String shippingCourse()//מחזיר מחרוזת בעלת פרטי השילוח
    {
        return this.sellingClient.getCountry() + " ----> " + this.buyingClient.getCountry();
    }
}
